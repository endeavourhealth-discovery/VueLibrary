declare module "google-palette";

import { Ref } from "vue";

import { useToast } from "primevue/usetoast";

import { ToastSeverity } from "../enums";
import { ToastOptions } from "../models";

export function useCopyToClipboard(valueToCopy?: Ref<string>, onCopyMessage?: string, onErrorMessage?: string) {
  const toast = useToast();

  function copyToClipboard() {
    return valueToCopy?.value;
  }

  async function copyObjectToClipboard(navigator: Navigator, object: any) {
    try {
      await navigator.clipboard.writeText(JSON.stringify(object));
      onCopy();
    } catch (error) {
      console.log(`Error copying to clipboard ${error}`);
      onCopyError();
    }
    return valueToCopy?.value;
  }

  function onCopy(): void {
    toast.add(new ToastOptions(ToastSeverity.SUCCESS, onCopyMessage ?? "Value copied to clipboard"));
  }

  function onCopyError(): void {
    toast.add(new ToastOptions(ToastSeverity.ERROR, onErrorMessage ?? "Failed to copy value to clipboard"));
  }

  return {
    copyToClipboard,
    copyObjectToClipboard,
    onCopy,
    onCopyError
  };
}

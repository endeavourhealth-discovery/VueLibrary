import { EntityReferenceNode, SearchResultSummary, TTEntity } from "./AutoGen";
import { GenericObject } from "./GenericObject";

export interface ExtendedTTEntity extends TTEntity, GenericObject {}

export interface TTBundle {
  entity: ExtendedTTEntity;
  predicates: { [index: string]: string };
}

export interface ExtendedEntityReferenceNode extends EntityReferenceNode {
  name: string;
  icon: string[];
  hasGrandChildren?: boolean;
}

export interface ExtendedSearchResultSummary extends SearchResultSummary {
  icon: string[];
  color: string;
  typeNames: string;
  favourite: boolean;
}
